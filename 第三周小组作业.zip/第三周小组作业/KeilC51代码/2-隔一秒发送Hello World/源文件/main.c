#include <REGX52.H>
#include "Delay.h"
#include "UART.h"

// �����ַ���
void send_string(unsigned char *str) {
    while (*str) {
        UART_SendByte(*str++);
    }
}

void main() 
	{
		UART_Init();
			while (1)
			{
        send_string("Hello, World!\n");
				Delay(1000);
			}
			
	}



