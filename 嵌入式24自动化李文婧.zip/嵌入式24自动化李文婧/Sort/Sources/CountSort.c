#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <stdlib.h>

// ��������
void CountSort(int arr[], int n) {
    int max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    int* count = (int*)malloc((max + 1) * sizeof(int));
    for (int i = 0; i <= max; i++) {
        count[i] = 0;
    }
    for (int i = 0; i < n; i++) {
        count[arr[i]]++;
    }
    int outputIndex = 0;
    for (int i = 0; i <= max; i++) {
        while (count[i] > 0) {
            arr[outputIndex++] = i;
            count[i]--;
        }
    }
    free(count);
}

// �����������
void generateArray(int arr[], int n)
{
    static int initialized = 0;
    if (!initialized) {
        srand((unsigned int)time(NULL));
        initialized = 1;
    }

    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 100000;
    }
}

// ���Դ������ݵ���ʱ
void testBig(void(*sortFunc)(int[], int), const char* sortName,
    int dataSize[], int numSize)
{
    LARGE_INTEGER freq, start, end;
    double time_used;
    QueryPerformanceFrequency(&freq);
    for (int i = 0; i < numSize; i++)
    {
        int* arr = (int*)malloc(dataSize[i] * sizeof(int));
        if (arr == NULL)
        {
            fprintf(stderr, "Memory allocation failed!\n");
            exit(EXIT_FAILURE);
        }
        generateArray(arr, dataSize[i]);

        QueryPerformanceCounter(&start);
        sortFunc(arr, dataSize[i]);
        QueryPerformanceCounter(&end);

        time_used = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
        printf("%s �� %d ���������л����� %f ��\n", sortName, dataSize[i], time_used);

        free(arr);
    }
}

// �����������ڴ���С�������µ���ʱ��ʹ�ø���ȷ��ʱ��
void testSmall(void (*sortFunc)(int[], int),
    const char* sortName, int numRepeats)
{
    LARGE_INTEGER freq, start, end;
    double time_used;
    int arr[100];

    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&start);
    for (int i = 0; i < numRepeats; i++)
    {
        generateArray(arr, 100);
        sortFunc(arr, 100);
    }
    QueryPerformanceCounter(&end);
    time_used = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
    printf("%s ��100�����ݵ� %d �����л����� %f ��\n", sortName, numRepeats, time_used);
}


 /*�����������ڴ���С�������µ���ʱ
void testSmall(void (*sortFunc)(int[], int),
    const char* sortName, int numRepeats)
{
    clock_t start, end;
    double time_used;
    int arr[100];
    generateArray(arr, 100);

    start = clock();
    if (start == -1)
    {
        fprintf(stderr, "Error getting start time!\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < numRepeats; i++)
    {
        sortFunc(arr, 100);
    }
    end = clock();
    if (end == -1)
    {
        fprintf(stderr, "Error getting end time!\n");
        exit(EXIT_FAILURE);
    }
    time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
    printf("%s ��100�����ݵ� %d �����л����� %f ��\n", sortName, numRepeats, time_used);
}*/

int main()
{
    int dataSizes[] = { 10000, 50000, 200000 };
    int numSizes = sizeof(dataSizes) / sizeof(dataSizes[0]);

    // ���Կ�������
    testBig(CountSort, "CountSort", dataSizes, numSizes);
    testSmall(CountSort, "CountSort", 100000);
    system("pause");
    return 0;

}

