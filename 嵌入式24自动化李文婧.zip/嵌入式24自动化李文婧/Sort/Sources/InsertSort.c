﻿#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <stdlib.h>

// 交换两个整数的函数
void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// 插入排序
void InsertSort(int arr[], int n) {
    int i, j;
    for (i = 1; i < n; i++) {
        for (j = i; j > 0; j--) {
            if (arr[j] < arr[j - 1]) {
                swap(&arr[j], &arr[j - 1]);
            }
            else {
                break;
            }
        }
    }
    /*for (i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");*/
}

// 生成随机数组
void generateArray(int arr[], int n)
{
    static int initialized = 0;
    if (!initialized) {
        srand((unsigned int)time(NULL));
        initialized = 1;
    }
    
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 100000;
    }
}

//// 主函数
//int main() {
//    static int arr[100000];
//    int n = sizeof(arr) / sizeof(arr[0]);
//    generateArray(arr, n);  // 先生成随机数组
//    InsertSort(arr, n);     // 再进行插入排序
//    return 0;
//}

// 测试大量数据的用时
// const char *sortName 用于存储排序函数的名称，
// 是一个字符串指针，以便在输出结果时标识是哪个排序函数的测试结果
void testBig(void(*sortFunc)(int[], int), const char* sortName,
    int dataSize[], int numSize)
{
    clock_t start, end;
    double time_used;
    for (int i = 0; i < numSize; i++) 
    {
        int* arr = (int*)malloc(dataSize[i] * sizeof(int));
        if (arr == NULL) 
        {
            fprintf(stderr, "Memory allocation failed!\n");
            exit(EXIT_FAILURE);
        }
        // 在每次循环中，使用  malloc  动态分配内存来创建一个大小为 
        //  dataSizes[i]  的整数数组  arr 
        // 然后调用  generateArray  函数生成随机数据填充到该数组中
        generateArray(arr, dataSize[i]);
        start = clock();
        if (start == -1) 
        {
            fprintf(stderr, "Error getting start time!\n");
            free(arr);
            exit(EXIT_FAILURE);
        }
        sortFunc(arr, dataSize[i]);
        end = clock();
        if (end == -1) 
        {
            fprintf(stderr, "Error getting end time!\n");
            free(arr);
            exit(EXIT_FAILURE);
        }
        time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
        printf("%s 的 %d 个数据运行花费了 %f 秒\n", sortName, dataSize[i], time_used);
        free(arr);
    }
}

// 测试排序函数在大量小数据量下的用时
void testSmall(void (*sortFunc)(int[], int),
    const char* sortName, int numRepeats) 
{
    clock_t start, end;
    double time_used;
    int arr[100];
    generateArray(arr, 100);

    start = clock();
    if (start == -1)
    {
        fprintf(stderr, "Error getting start time!\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < numRepeats; i++) 
    {
        sortFunc(arr, 100);
    }
    end = clock();
    if (end == -1) 
    {
        fprintf(stderr, "Error getting end time!\n");
        exit(EXIT_FAILURE);
    }
    time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
    printf("%s 对100个数据的 %d 次运行花费了 %f 秒\n", sortName, numRepeats, time_used);
}

int main()
{
    int dataSizes[] = { 10000, 50000, 200000 };
    int numSizes = sizeof(dataSizes) / sizeof(dataSizes[0]);

    // 测试插入排序
    testBig(InsertSort, "InsertSort", dataSizes, numSizes);
    testSmall(InsertSort, "InsertSort", 100000);
    return 0;
    system("pause");
}

