#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <stdlib.h>

// ��ȡ�������λ�������ڻ�����������
int getMax(int arr[], int n) {
    int mx = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > mx) {
            mx = arr[i];
        }
    }
    int digits = 0;
    while (mx != 0) {
        mx /= 10;
        digits++;
    }
    return digits;
}

// ������������
void RadixCountSort(int arr[], int n) {
    int exp, max = getMax(arr, n);
    int* output = (int*)malloc(n * sizeof(int));
    for (exp = 1; max / exp > 0; exp *= 10) {
        int count[10] = { 0 };
        for (int i = 0; i < n; i++) {
            count[(arr[i] / exp) % 10]++;
        }
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            output[count[(arr[i] / exp) % 10] - 1] = arr[i];
            count[(arr[i] / exp) % 10]--;
        }
        for (int i = 0; i < n; i++) {
            arr[i] = output[i];
        }
    }
    free(output);
}

// �����������
void generateArray(int arr[], int n)
{
    static int initialized = 0;
    if (!initialized) {
        srand((unsigned int)time(NULL));
        initialized = 1;
    }

    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 100000;
    }
}

// ���Դ������ݵ���ʱ
void testBig(void(*sortFunc)(int[], int), const char* sortName,
    int dataSize[], int numSize)
{
    LARGE_INTEGER freq, start, end;
    double time_used;
    QueryPerformanceFrequency(&freq);
    for (int i = 0; i < numSize; i++)
    {
        int* arr = (int*)malloc(dataSize[i] * sizeof(int));
        if (arr == NULL)
        {
            fprintf(stderr, "Memory allocation failed!\n");
            exit(EXIT_FAILURE);
        }
        generateArray(arr, dataSize[i]);

        QueryPerformanceCounter(&start);
        sortFunc(arr, dataSize[i]);
        QueryPerformanceCounter(&end);

        time_used = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
        printf("%s �� %d ���������л����� %f ��\n", sortName, dataSize[i], time_used);

        free(arr);
    }
}

// �����������ڴ���С�������µ���ʱ��ʹ�ø���ȷ��ʱ��
void testSmall(void (*sortFunc)(int[], int),
    const char* sortName, int numRepeats)
{
    LARGE_INTEGER freq, start, end;
    double time_used;
    int arr[100];

    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&start);
    for (int i = 0; i < numRepeats; i++)
    {
        generateArray(arr, 100);
        sortFunc(arr, 100);
    }
    QueryPerformanceCounter(&end);
    time_used = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
    printf("%s ��100�����ݵ� %d �����л����� %f ��\n", sortName, numRepeats, time_used);
}


/*�����������ڴ���С�������µ���ʱ
void testSmall(void (*sortFunc)(int[], int),
    const char* sortName, int numRepeats)
{
    clock_t start, end;
    double time_used;
    int arr[100];
    generateArray(arr, 100);

    start = clock();
    if (start == -1)
    {
        fprintf(stderr, "Error getting start time!\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < numRepeats; i++)
    {
        sortFunc(arr, 100);
    }
    end = clock();
    if (end == -1)
    {
        fprintf(stderr, "Error getting end time!\n");
        exit(EXIT_FAILURE);
    }
    time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
    printf("%s ��100�����ݵ� %d �����л����� %f ��\n", sortName, numRepeats, time_used);
}*/

int main()
{
    int dataSizes[] = { 10000, 50000, 200000 };
    int numSizes = sizeof(dataSizes) / sizeof(dataSizes[0]);

    // ���Կ�������
    testBig(RadixCountSort, "RadixCountSort", dataSizes, numSizes);
    testSmall(RadixCountSort, "RadixCountSort", 100000);
    system("pause");
    return 0;

}

