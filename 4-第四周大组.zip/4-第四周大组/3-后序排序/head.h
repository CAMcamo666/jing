#ifndef BINARYSORTTREE_BINARY_SORT_TREE_H
#define BINARYSORTTREE_BINARY_SORT_TREE_H

typedef int BTDataType;
typedef struct BinaryTreeNode
{
	struct BinaryTreeNode* left;
	struct BinaryTreeNode* right;
	BTDataType data;
}BTNode;

BTNode* insert(BTNode* root, int data);
BTNode* search(BTNode* root, int data);
BTNode* findMin(BTNode* root);
BTNode* delete(BTNode* root, int data);

#endif


