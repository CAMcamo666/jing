#ifndef __IIC_H__
#define __IIC_H__

#include "public.h"

sbit IIC_SCL=P2^1;
sbit IIC_SDA=P2^0;

void iic_start(void);
void iic_stop(void);
void icc_ack(void);
void icc_nack(void);
u8 icc_wait_ack(void);
void icc_write_byte(u8 ack);
u8 icc_read_byte(u8 ack);

#endif