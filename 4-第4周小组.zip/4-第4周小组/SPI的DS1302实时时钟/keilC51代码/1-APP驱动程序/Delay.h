
#ifndef __DELAY_H__
#define __DEKAY_H__

void Delay(unsigned int xms);

#endif